package com;

public interface Printable {
    void printDetails();
}
