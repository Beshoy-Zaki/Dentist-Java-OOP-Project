package com;

public interface Notifiable {
    void sendNotification();
    String getNotificationMessage();
}